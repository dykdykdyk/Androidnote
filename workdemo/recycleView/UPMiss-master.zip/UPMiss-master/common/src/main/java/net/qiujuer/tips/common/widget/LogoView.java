package net.qiujuer.tips.common.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public class LogoView extends View {
    public LogoView(Context context) {
        super(context);
    }

    public LogoView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public LogoView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
