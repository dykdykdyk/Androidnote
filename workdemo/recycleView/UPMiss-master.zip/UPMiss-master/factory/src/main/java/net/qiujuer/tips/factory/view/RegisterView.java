package net.qiujuer.tips.factory.view;

/**
 * Register view interface
 */
public interface RegisterView extends LoginView {
    String getConfirmPassword();
}
