package net.qiujuer.tips.factory.cache.notify;


import java.util.List;

public interface UpdateListNotify<T> {
    void update(List<T> caches);
}
