package net.qiujuer.tips.factory.cache.notify;


import net.qiujuer.tips.factory.cache.CacheStaCount;

public interface UpdateSTTTNotify {
    void update(CacheStaCount cache);
}
