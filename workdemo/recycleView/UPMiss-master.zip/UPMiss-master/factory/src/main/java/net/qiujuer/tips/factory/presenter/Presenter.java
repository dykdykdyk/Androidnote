package net.qiujuer.tips.factory.presenter;

/**
 * Created by qiujuer on 15/7/9.
 * This is a Presenter interface
 */
public interface Presenter {
    void destroy();
}
