package net.qiujuer.tips.factory.view;

public interface SettingView {
    int getLeadTime();

    int[] getColor();

    void setLeadTime(int time);

    void setColor(int[] color);
}
